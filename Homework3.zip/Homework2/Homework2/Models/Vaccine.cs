﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Homework2.Models
{
    public class Vaccine
    {
      
        public int id { get; set; }
        public String name { get; set; }
        public String dosesRequired { get; set; }
        public String daysBetweenDoses { get; set; }
        public int totalDosesReceived { get; set; }
        public int totalDosesLeft { get; set; }

        public Vaccine() { }

        public Vaccine(int id, string name, string dosesRequired, string daysBetweenDoses, int totalDosesReceived, int totalDosesLeft) {
            this.id = id;
            this.name = name;
            this.dosesRequired = dosesRequired;
            this.daysBetweenDoses = daysBetweenDoses;
            this.totalDosesReceived = totalDosesReceived;
            this.totalDosesLeft = totalDosesLeft;
        } 


    }
}
