﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Homework2.Models
{
    public class Patient
    {
        [ForeignKey("vaccineId")]
    
        public int patientId { get; set; }
        public string patientName { get; set; }
        public int vaccineId { get; set; }
        public DateTime? firstDose { get; set; }
        public DateTime? secondDose { get; set; }
        public Vaccine Vaccine { get; set; }

        public Patient() { }

        public Patient(int patientId, string patientName, int vaccineId, DateTime firstDose, DateTime secondDose) {
            this.patientId = patientId;
            this.patientName = patientName;
            this.vaccineId = vaccineId;
            this.firstDose = firstDose;
            this.secondDose = secondDose;
        }
    }
}
