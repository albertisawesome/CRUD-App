﻿using Homework2.Models;
using Homework2.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Homework2.Controllers
{
    public class VaccinesController : Controller
    {
        private readonly IVaccineService _vaccineService;


        public VaccinesController(IVaccineService vaccineService) {
            _vaccineService = vaccineService;
        }


        public IActionResult Index()
        {
            return View(_vaccineService.GetVaccines());
        }

        public IActionResult Details(int id) {
            return View(_vaccineService.GetVaccine(id));
        }

        [HttpGet]
        public IActionResult Add() {
            return View();
        }
        [HttpPost] 
        public IActionResult Add(Vaccine vaccine) {
            _vaccineService.AddVaccine(vaccine);
            return RedirectToAction("Index");
        }

        [HttpGet]
        public IActionResult Edit(int id)
        {
         /*   ViewBag.Supervisors = _vaccineService.GetVaccines()
                .Where(e => e.id != id)
                .Select(e => new SelectListItem(e.name, e.id.ToString()))
                .ToList();*/

            /* ViewBag.Supervisors = _vaccineService.GetVaccines()
                .Where(e => e.id != id)
                .Select(e => new SelectListItem(e.dosesRequired, e.dosesRequired.ToString()))
                .ToList();*/          
            return View(_vaccineService.GetVaccine(id));
        }

        [HttpPost]
        public IActionResult Edit(int id, Vaccine update)
        {
            var vaccine = _vaccineService.GetVaccine(id);
            vaccine.name = update.name;
            vaccine.dosesRequired = update.dosesRequired;
            vaccine.daysBetweenDoses = update.daysBetweenDoses;
            _vaccineService.SaveChanges();
            return RedirectToAction("Index");
        }

        [HttpGet]
        public IActionResult AddDoses(int id)
        {
            return View(_vaccineService.GetVaccines());
      
        }
        [HttpPost]
        public IActionResult AddDoses(int id, [Bind]Vaccine update)
        {
      
            Vaccine vaccine = _vaccineService.GetVaccine(id);
            
            vaccine.totalDosesReceived += update.totalDosesReceived;
            vaccine.totalDosesLeft = vaccine.totalDosesReceived;


            _vaccineService.SaveChanges();

            return RedirectToAction("Index");
        }

    }
}
