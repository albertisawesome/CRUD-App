﻿using Homework2.Models;
using Homework2.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Homework2.Controllers
{
    /*  create table Patients(
          patientId int IDENTITY(1, 1) PRIMARY KEY,
          patientName varchar(255),
		  vaccineId int,
          firstDose date,
          secondDose date,
                
);

               insert into Patients(patientName, vaccineId, firstDose, secondDose) values('John Doe', 1, '02-18-2021', '03-11-2021');
               );*/

    public class PatientsController : Controller
    {
        private readonly IPatientService _patientService;
  

        public PatientsController(IPatientService patientService)
        {
            _patientService = patientService;
        }

        public IActionResult Index()
        {
            return View(_patientService.GetPatients());
        }


        [HttpGet]
        public IActionResult Received(int id)
        {
            Patient patient = new Patient();

            patient = _patientService.GetPatient(id);

            Vaccine vaccine = _patientService.GetVaccine(patient.vaccineId);
            patient.Vaccine = vaccine;
            vaccine.totalDosesLeft--;
           
            patient.secondDose = DateTime.Now;
           
            _patientService.SaveChanges();
            return RedirectToAction("Index");
        }


        [HttpGet]
        public IActionResult Add(int patientId)
        {
            return View(_patientService.GetVaccines());

        }
        [HttpPost]
        public IActionResult Add(string patientName, int vaccineId)
        {
            
            Patient patient = new Patient();
            patient.patientName = patientName;
            patient.vaccineId = vaccineId;

            Vaccine vaccine = _patientService.GetVaccine(vaccineId);

            patient.Vaccine = vaccine;
            vaccine.totalDosesLeft--;



            patient.Vaccine.totalDosesLeft = vaccine.totalDosesLeft--;
            patient.firstDose = DateTime.Now;
            _patientService.AddPatient(patient);
            _patientService.SaveChanges();

            return RedirectToAction("Index");
        }


    }
}
