﻿using Homework2.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;


namespace Homework2.Services
{
    public interface IVaccineService
    {
        List<Vaccine> GetVaccines();
        Vaccine GetVaccine(int id);

        void AddVaccine(Vaccine vaccine);

        void SaveChanges();
    }

    public class VaccineService : IVaccineService
    {
        private readonly AppDbContext _db;

        public VaccineService(AppDbContext db)
        {
            _db = db;
        }
        public List<Vaccine> GetVaccines()
        {
            return _db.Vaccines.ToList();
        }

        public Vaccine GetVaccine(int id)
        {
            return _db.Vaccines.Where(e => e.id == id).SingleOrDefault();

        }

        public void AddVaccine(Vaccine vaccine)
        {
            _db.Vaccines.Add(vaccine);
            _db.SaveChanges();
        }

        public void SaveChanges() => _db.SaveChanges();

        public class MockVaccineService : IVaccineService
        {
            private List<Vaccine> vaccines;

            public MockVaccineService()
            {
                vaccines = new List<Vaccine>
            {
                new Vaccine(1, "Pfizer/BioNTech", "2", "24", 10000, 10000),
                new Vaccine(2, "Johnson & Johnson", "1", "", 5000, 5000)

            };



            }

            public void AddVaccine(Vaccine vaccine)
            {
                throw new NotImplementedException();
            }

            public Vaccine GetVaccine(int id)
            {
                throw new NotImplementedException();
            }

            public List<Vaccine> GetVaccines()
            {
                return vaccines;
            }

            public void SaveChanges() { }
        }
    }
}
