﻿using Homework2.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;


namespace Homework2.Services
{
    public interface IPatientService
    {
        List<Vaccine> GetVaccines();
        List<Patient> GetPatients();
        Patient GetPatient(int id);

        Vaccine GetVaccine(int id);

        void AddPatient(Patient patient);

        void SaveChanges();
    }

    public class PatientService : IPatientService
    {
        private readonly AppDbContext _db;

        public PatientService(AppDbContext db)
        {
            _db = db;
        }

        public List<Vaccine> GetVaccines() {
            return _db.Vaccines.ToList();
        }

        public Vaccine GetVaccine(int id) {
            return _db.Vaccines.Where(e => e.id == id).SingleOrDefault();
        }
        public List<Patient> GetPatients()
        {
            return _db.Patients.Include("Vaccine").ToList();
        }

        public Patient GetPatient(int id)
        {
            return _db.Patients.Where(e => e.patientId == id).SingleOrDefault();

        }

        public void AddPatient(Patient patient)
        {
            _db.Patients.Add(patient);
            _db.SaveChanges();
        }

        public void SaveChanges() => _db.SaveChanges();

       
    }
}
