﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Week4Lab
{
    class Program
    {
        static void Print<T>(string label, IEnumerable<T> results)
        {
            Console.WriteLine(label);
            foreach (var result in results)
                Console.WriteLine("\t{0}", result);
        }

        static void Main(string[] args)
        {
            Company c = new Company();

            // 1. List the names of the employees who do not have a supervisor.
            // The results should combine FirstName and LastName into one string.
            var r1 = from e in c.Employees 
                     where e.SupervisorId is null 
                     select (e.FirstName + ' ' + e.LastName);
            Print("Q1 (query)", r1);

            // 2. List the last names of the employees whose last name starts with D.
            // The results should be listed in alphabetic order without duplicates.
            var r2 = from employee in c.Employees
                     where employee.LastName.StartsWith("D")
                     orderby employee.FirstName
                     select employee.LastName;
            Print("Q2 (query)", r2.Distinct());

            // 3. List the names of the employees who are on the project Blue.
            // The results should combine FirstName and LastName into one string.
            var r3 = (from p in c.Projects where p.Name == "Blue" select p.Members.Select(m => m.FirstName + ' ' + m.LastName)).Single();

            Print("Q3 (query)", r3);

            // 4. Find Jane Doe's subordinates, i.e. the employees who are supervised by Jane Doe.
            var r4 = from e1 in c.Employees 
                     join e2 in c.Employees 
                     on e1.SupervisorId equals e2.Id
                     where e2.FirstName == "Jane" && e2.LastName == "Doe"
                     select e1;
            Print("Q4 (query)", r4);

            // 5. Find the employee(s) who were hired in 2015 and worked on the project Blue.
            var r5 = (from employee in c.Employees where employee.DateHired.Year == 2015 select employee)
                .Intersect((from p in c.Projects where p.Name == "Blue" select p.Members).Single());
            Print("Q5 (query)", r5);

        }
    }
}
